package com.msn9110.eztalk.adapter;

import android.widget.RadioButton;
import android.widget.TextView;

public class ViewHolder{
    public TextView name;
    public RadioButton select;
}
