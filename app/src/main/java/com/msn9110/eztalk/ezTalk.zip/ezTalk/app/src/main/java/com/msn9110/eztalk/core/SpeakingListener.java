package com.msn9110.eztalk.core;

public interface SpeakingListener {
    void onPreSpeak(final String message);
}
