package com.msn9110.eztalk.listener;


import android.view.View;

public interface OnCursorChangedListener {
    void onCursorChanged(View view);
}
