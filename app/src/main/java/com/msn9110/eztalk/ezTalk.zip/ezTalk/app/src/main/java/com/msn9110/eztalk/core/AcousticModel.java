package com.msn9110.eztalk.core;

//import org.tensorflow.lite.Interpreter;

public class AcousticModel {

    public AcousticModel() {
    }
}
